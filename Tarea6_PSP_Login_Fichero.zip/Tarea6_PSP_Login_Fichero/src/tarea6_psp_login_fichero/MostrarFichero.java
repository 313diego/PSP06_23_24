/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea6_psp_login_fichero;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author diego
 */
public class MostrarFichero {

    public void mostrarFichero() {
        String patron = ".{1,8}\\.[a-zA-Z]{3}"; // Patrón de 1 a 8 caracteres mas . mas extension de 3 caracteres
        boolean entradaValida = false;
        while (!entradaValida) {
            String entrada = JOptionPane.showInputDialog("Introduce el nombre del fichero a mostrar (fichero.txt)");
            System.out.println("Introduce el nombre del fichero a mostrar (fichero.txt)");
            String nomFichero, linea;
            String documento = "";
            Pattern pattern = Pattern.compile(patron);
            Matcher matcher = pattern.matcher(entrada);
            // Comprueba si la entrada coincide con el patrón
            if (matcher.matches()) {
                entradaValida = true;
                JOptionPane.showMessageDialog(null, "El nombre del fichero es valido");
                System.out.println("El nombre del fichero es válido.");
                nomFichero = entrada;
                try {
                    File fichero = new File(nomFichero);
                    if (fichero.exists()) {
                        FileReader fr = new FileReader(fichero);
                        BufferedReader br = new BufferedReader(fr);
                        while ((linea = br.readLine()) != null) {
                            System.out.println(linea);
                            documento += linea + "\n";
                        }
                        JOptionPane.showMessageDialog(null, documento);
                        br.close();
                    } else {
                        JOptionPane.showMessageDialog(null, "No existe ningun fichero con ese nombre");
                        System.out.println("No existe ningun fichero con ese nombre");
                    }
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(null, "El nombre del fichero no es valido, por favor inténtalo de nuevo.");
                System.out.println("El nombre del fichero no es valido, por favor, inténtalo de nuevo.");
            }
        }
    }
}
