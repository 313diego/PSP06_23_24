/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea6_psp_login_fichero;

/**
 *
 * @author diego
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login login = new Login();
        
        MostrarFichero mf = new MostrarFichero();
        System.out.println("Validar usuario");
        System.out.println("-----------------------------------------------");
        login.validarUsuario();
        System.out.println("Validar nombre de fichero y mostrarlo");
        System.out.println("-----------------------------------------------");
        mf.mostrarFichero();
    }
    
}
