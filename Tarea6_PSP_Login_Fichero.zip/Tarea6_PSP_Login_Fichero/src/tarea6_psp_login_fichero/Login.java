/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea6_psp_login_fichero;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author diego
 */
public class Login {
    
    public void validarUsuario(){
        String patron = "[a-z]{8}"; // Patrón para ocho letras minusculas consecutivas

        boolean entradaValida = false;
        
        while (!entradaValida) {
            String entrada = JOptionPane.showInputDialog("Introduce el usuario (ocho letras minusculas):");
            System.out.println("Introduce el usuario (ocho letras minusculas):");
            Pattern pattern = Pattern.compile(patron);

            Matcher matcher = pattern.matcher(entrada);
            // Comprueba si la entrada coincide con el patrón
            if (matcher.matches()) {
                entradaValida = true;
                JOptionPane.showMessageDialog(null, "El usuario es válido.");
                System.out.println("El usuario es válido.");
            } else {
                JOptionPane.showMessageDialog(null, "El usuario no es valido, por favor, "
                        + "inténtalo de nuevo.");
                System.out.println("El usuario no es valido, por favor, inténtalo de nuevo.");
            }
        }
    }

}
